public interface IAbilityTarget: IAbility
{
    void Init(CollisionAbility parent);  
}
