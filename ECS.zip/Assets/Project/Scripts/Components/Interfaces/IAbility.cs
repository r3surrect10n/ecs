public interface IAbility
{
    public void Execute();
}
