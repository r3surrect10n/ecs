public interface ITakeDamage
{
    void Damage (float damage);
}
